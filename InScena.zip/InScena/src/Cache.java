import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;

public class Cache implements Serializable{//00
    public final String emailCliente;//01
    public final String cittaSelezionata;//02
    public final String orarioSelezionato;//03
    public final LocalDate dataSelezionata;//04
    public final int rigaSpettacoloSelezionata;//05
    public final int idSpettacoloSelezionato;
    public final ArrayList<postazionePlatea> listaPostiSelezionati;//07
    
    public Cache(InterfacciaGrafica interfacciaInScena) {//08
        emailCliente=pannelloVisualeEmailCliente.getCampoEmail().getText();
        rigaSpettacoloSelezionata=pannelloSelezioneSpettacoli.getTabellaVisuale().getSelectionModel().getSelectedIndex();
        cittaSelezionata=pannelloSelezioneSpettacoli.getCitta().getValue().toString();
        orarioSelezionato=pannelloSelezioneSpettacoli.getOrario().getValue().toString();
        dataSelezionata=pannelloSelezioneSpettacoli.getData().getValue();
        idSpettacoloSelezionato=pannelloSelezioneSpettacoli.getTabella().getIdSpettacoloSelezionato();
        listaPostiSelezionati=pannelloPostazioniPlatea.getMatricePlatea().getListaPostiSelezionati();
    }
    
    public String getEmailCliente(){    return emailCliente;    }
    public String getCittaSelezionata() { return cittaSelezionata;  }
    public String getOrarioSelezionato() { return orarioSelezionato;  }
    public LocalDate getDataSelezionata(){  return dataSelezionata; }
    public int getIndiceRigaSpettacoloSelezionata() { return rigaSpettacoloSelezionata; }
    public int getIdSpettacoloSelezionato() {   return idSpettacoloSelezionato; }
    public ArrayList<postazionePlatea> getListaSpettacoliSelezionati()  {   return listaPostiSelezionati;   }
}

/***********************************COMMENTI***********************************/
/*
00) L'oggetto salva la cache locale degli input dell'utente.

01) L'email associata al cliente da ripristinare all'apertura

02) La citta selezionata da ripristinare

03) L'orario selezionato da ripristinare

04) La data selezionata da ripristinare

05) La riga selezionata dalla tabella degli spettacoli risultanti, serve
    memorizzarla per poter caricare la disponibilità dello spettacolo che era stato
    selezionato

06) La lista delle postazioni selezionate viene salvata per poterle selezionare
    nuovamente in giallo alla riapertura

07) Il costruttore, invocato al momento del salvataggio della cache, e quindi
    alla chiusura dell'applicazione, salva tutti gli input dell'utente
    prelevandoli dall'oggetto InterfacciaGrafica.
*/