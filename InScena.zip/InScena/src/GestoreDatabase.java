import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class GestoreDatabase {
    
    
    public static List<spettacoloTeatrale> cercaSpettacoli(String sceltaCitta, java.sql.Date sceltaData,
            String sceltaOrario) { //01
        
        List<spettacoloTeatrale> listaSpettacoli = new ArrayList<>();
        
        try(Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/inscena","root",""); 
            PreparedStatement ps = conn.prepareStatement(
                    "SELECT S.id,teatro,S.opera,genere,dettagli"
                    + " FROM spettacoli S INNER JOIN opera_teatrale O ON S.opera=O.opera"
                    + " WHERE citta=? and data=? and orario=?");
        ) {
            ps.setString(1, sceltaCitta);
            ps.setDate(2, sceltaData);
            ps.setString(3, sceltaOrario);
            ResultSet rs = ps.executeQuery(); 
            listaSpettacoli.clear(); 
            while(rs.next()) 
                listaSpettacoli.add(new spettacoloTeatrale(rs.getInt("id"),rs.getString("teatro"),
                        rs.getString("opera"),rs.getString("genere"), rs.getString("dettagli"))); 
        } catch(SQLException e) {
            System.err.println(e.getMessage());
        }
        return listaSpettacoli;
    }
    
    public static List<postazionePlatea> 
        caricaDisponibilitaPostiSpettacoloSelezionato(int idSpettacolo) {//02
        List<postazionePlatea> listaDisponibilitaPostazioni = new ArrayList<>();
        
        try(Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/inscena","root",""); 
            PreparedStatement ps = conn.prepareStatement(
                    "SELECT indice_riga, indice_colonna, stato_postazione"
                    + " FROM disponibilita_x_spettacolo"
                    + " WHERE id_spettacolo=?");
        ) {
            ps.setInt(1, idSpettacolo);
            ResultSet rs = ps.executeQuery(); 
            listaDisponibilitaPostazioni.clear();
            while(rs.next()) 
                listaDisponibilitaPostazioni.add(new postazionePlatea(
                        rs.getInt("indice_riga"),rs.getInt("indice_colonna"),
                        rs.getInt("stato_postazione"))); 
        } catch(SQLException e) {
            System.err.println(e.getMessage());
        }
        return listaDisponibilitaPostazioni;
    }
    
    public static int nuovaPrenotazioneSpettacolo(String emailCliente,
            int idSpettacoloPrenotato) {//03
        
        int id_prenotazione=-1;
        
        try(Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/inscena","root",""); 
            PreparedStatement ps = conn.prepareStatement(
                    "INSERT INTO prenotazioni_spettacoli"
                    + "(email, id_spettacolo)"
                    + "VALUES (?,?)", Statement.RETURN_GENERATED_KEYS);
        ) {
            ps.setString(1, emailCliente);
            ps.setInt(2, idSpettacoloPrenotato);
            ps.executeUpdate();
            ResultSet generatedKey = ps.getGeneratedKeys();
            if(generatedKey.next()){
                id_prenotazione=generatedKey.getInt(1);
                System.out.println("Prenotazione n."+id_prenotazione);
            }
        } catch(SQLException e) {
            System.err.println(e.getMessage());
        }
        
        return id_prenotazione;
    }
    
    
    public static void inserisciPostiPrenotazione(int id_prenotazione,
            int indice_riga, int indice_colonna) {//04
                
        try(Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/inscena","root",""); 
            PreparedStatement ps = conn.prepareStatement(
                    "INSERT INTO postazioni_x_prenotazione"
                    + " VALUES (?,?,?)");
        ) {
            ps.setInt(1, id_prenotazione);
            ps.setInt(2, indice_riga);
            ps.setInt(3, indice_colonna);
            ps.executeUpdate();
            System.out.println("inserito posto "+indice_riga+" "+indice_colonna+" prenotazione n."+id_prenotazione);
        } catch(SQLException e) {
            System.err.println(e.getMessage());
        }
    }
    
    
    public static void impostaStatoPostazioniPrenotate(int idSpettacoloPrenotato,
            int indice_riga, int indice_colonna) {//05
        
        try(Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/inscena","root",""); 
            PreparedStatement ps = conn.prepareStatement(
                    "UPDATE disponibilita_x_spettacolo"
                    + " SET stato_postazione=1 "
                    + " WHERE id_spettacolo=? AND indice_riga=? AND indice_colonna=?");
        ) {
            ps.setInt(1, idSpettacoloPrenotato);
            ps.setInt(2, indice_riga);
            ps.setInt(3, indice_colonna);
            ps.executeUpdate();
            System.out.println("stato postazione cambiato!");
        } catch(SQLException e) {
            System.err.println(e.getMessage());
        }
    }
    
    public static void liberaPostazioniSelezionate(int idSpettacoloPrenotato,
            int indice_riga, int indice_colonna) {//06
        
        try(Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/inscena","root",""); 
            PreparedStatement ps = conn.prepareStatement(
                    "UPDATE disponibilita_x_spettacolo"
                    + " SET stato_postazione=0 "
                    + " WHERE id_spettacolo=? AND indice_riga=? AND indice_colonna=?");
        ) {
            ps.setInt(1, idSpettacoloPrenotato);
            ps.setInt(2, indice_riga);
            ps.setInt(3, indice_colonna);
            ps.executeUpdate();
            System.out.println(indice_riga+"-"+indice_colonna+" postazione liberata!");
        } catch(SQLException e) {
            System.err.println(e.getMessage());
        }
    }
    
    
    public static int ricavaIdPrenotazioneDaDisdire(String email,
            int idSpettacoloPrenotato) {//07
        
        int id_prenotazione_da_disdire=-1;
        
        try(Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/inscena","root",""); 
            PreparedStatement ps = conn.prepareStatement(
                    "select PS.id_prenotazione " +
                    "from prenotazioni_spettacoli PS " +
                    "where email=? " +
                    "	and id_spettacolo=?");
        ) {
            ps.setString(1, email);
            ps.setInt(2, idSpettacoloPrenotato);
            ResultSet rs = ps.executeQuery();
            if(rs.next())
            id_prenotazione_da_disdire=rs.getInt("id_prenotazione");
        } catch(SQLException e) {
            System.err.println(e.getMessage());
        }
        return id_prenotazione_da_disdire;
    }
    
    public static void disdiciPrenotazione(String email,
            int idSpettacoloPrenotato) {//08
        
        try(Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/inscena","root",""); 
            PreparedStatement ps = conn.prepareStatement(
                    "delete PS.*, PP.* " +
                    "from prenotazioni_spettacoli PS"
                  + " inner join postazioni_x_prenotazione PP " +
                    " ON PS.id_prenotazione = PP.id_prenotazione " +
                    "where PS.email=? " +
                    "	and PS.id_spettacolo=? ");
        ) {
            ps.setString(1, email);
            ps.setInt(2, idSpettacoloPrenotato);
            ps.executeUpdate();
            System.out.println("prenotazione disdetta!");
        } catch(SQLException e) {
            System.err.println(e.getMessage());
        }
    }
    
    public static List<popolaritaOperaTeatrale> getListaSpettacoliPiuPopolari
        (int periodoInGiorniDaOggi, int daMostrare) {//09
        List<popolaritaOperaTeatrale> listaSpettacoliPiuPopolari = new ArrayList<>();
        
        try(Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/inscena","root",""); 
            PreparedStatement ps = conn.prepareStatement(
                    "SELECT S.opera, D.quanti AS BigliettiVenduti, S.data AS DataSpettacolo " +
                    "FROM( " +
                    "SELECT PS.id_spettacolo, COUNT(*) as quanti " +
                    "FROM postazioni_x_prenotazione PP " +
                    "INNER JOIN prenotazioni_spettacoli PS " +
                    "ON PP.id_prenotazione=PS.id_prenotazione " +
                    "GROUP BY PS.id_spettacolo " +
                    ") as D INNER JOIN spettacoli S ON S.id = D.id_spettacolo " +
                    "WHERE S.data BETWEEN ('2020-04-05' - INTERVAL ? DAY) AND '2020-04-05' " +
                    "ORDER BY D.quanti DESC ");
        ) {
            ps.setInt(1, periodoInGiorniDaOggi);
            ResultSet rs = ps.executeQuery(); 
            while(rs.next()) 
                listaSpettacoliPiuPopolari.add(new popolaritaOperaTeatrale(
                        rs.getString("opera"), rs.getInt("BigliettiVenduti")));
        } catch(SQLException e) {
            System.err.println(e.getMessage());
        }
        return listaSpettacoliPiuPopolari;
    }
    
}

/***********************************COMMENTI***********************************/
/*
01) Funzione che restituisce una List di spettacoloTeatrale compatibili ai
    valori dei campi di input selezionati; tale lista viene legata
    alla tabellaSpettacoli.

02) Funzione che, a seguito della selezione di uno spettacolo nella tableview,
    carica la matrice delle postazioni relativa a tale spettacolo. La disponibilità
    è costruita andando a leggere, per ogni postazione, il relativo stato (0-1);
    se lo stato è 0 nel chiamante visualizzerò un imageview con poltrona verde,
    rossa altrimenti.

03) Funzione che inserisce nel DB una nuova prenotazione; viene invocata dalla
    classe gestoreRicercaEPrenotazioneSpettacoli a seguito della pressione
    sul bottone PROSEGUI.

04) Funzione che inserisce nella tabella postazioni_x_prenotazione ogni postazione
    scelta. Associa quindi nel DB una prenotazione ai posti prenotati

05) Funzione che serve per settare lo stato postazione a 1 delle postazioni 
    selezionate e confermate con una prenotazione; cosi facendo verranno caricate 
    come rosse ad una nuova selezione dello stesso spettacolo dalla tabella.
    Esegue un update per ogni postazione selezionata.

06) Funzione che libera le postazioni relative a una prenotazione settando il
    valore del loro stato = 0 nella tabella delle disponibilità nel DB

07) Funzione di utilità che serve per vedere se a disdire è effettivamente
    il possessore della prenotazione. Se ritorna -1 viene stampato un semplice 
    msg d'errore

08) Funzione che serve a eliminare tutti i record relativi a una prenotazione
    che viene disdetta. Elimina il record unico nella tabella prenotazioni_x_spettacoli
     della prenotazione X e tutti i record dei posti relativi alla prenotazione X
     nella tabella postazioni_x_prenotazione

09) Funzione che permette di inizializzare la lista di oggetti popolaritaOperaTeatrale,
    che verrà restituita al chiamante (pannello destro) e permetterà di 
    inizializzare il grafico relativo.
*/
