import javafx.application.*;
import javafx.scene.*;
import javafx.stage.*;

public class InScena extends Application {
    private final static String FILE_CONFIGURAZIONE = "config.xml", // 01)
                                SCHEMA_CONFIGURAZIONE = "config.xsd", // 02)
                                FILE_CACHE = "cache.bin"; // 03)
    static ParametriConfigurazioneXML config;//04
    private InterfacciaGrafica interfaccia; //05
    
    public static void main(String[] args) 
    {
        Application.launch(args);
    }
     
    public void start(Stage stage) {        
        config = // 07)
            new ParametriConfigurazioneXML(
                ValidatoreXML.valida(GestoreFile.carica(FILE_CONFIGURAZIONE), SCHEMA_CONFIGURAZIONE, false) ? // 08)
                    GestoreFile.carica(FILE_CONFIGURAZIONE) : null // 09)
            );
        GestoreLogAttivitaXML.creaLog("Apertura applicazione", config); // 10)
        
        interfaccia = new InterfacciaGrafica(config, FILE_CACHE);//11
        
        stage.setTitle("InScena"); 
        Scene scene = new Scene(interfaccia.getContenitore(),config.getLarghezza(),
                config.getAltezza()); //12
        stage.setScene(scene);
        
        stage.setOnCloseRequest((WindowEvent we) -> { //13
            GestoreLogAttivitaXML.creaLog("Chiusura applicazione", config);//14
            GestoreCache.salva(interfaccia, FILE_CACHE);//15
        });
        
        stage.show();
    }
}


/***********************************COMMENTI***********************************/
/*
01) All'avvio, il sistema legge dal file di configurazione i seguenti dati:
        a) Font, dimensioni, colore del background
        c) Indirizzo IP del client, indirizzo IP e porta del server log

02) File di schema XSD per validare il file di configurazione XML.

03) File di cache locale degli input. Alla chiusura, il sistema salva:
        a) città selezionata
        b) data selezionata
        c) orario selezionato
        d) spettacolo selezionato dalla tabella
        e) postazioni della platea selezionate

04) Classe che contiene i parametri di configurazione XML.

05) Classe che gestisce l'Interfaccia Grafica.

08) Si prelevano i parametri di configurazione solo se la validazione del
    relativo file XML avviene con successo.

09) Se la validazione e' avvenuta con successo, si prelevano i parametri di
    configurazione dal file XML. Altrimenti, si passa null al costruttore
    di ParametriConfigurazioneXML, che si occupera' ad impostare dei valori
    di default.

10) Si invia un log ad un server remoto contenente, riguardo l'avvio
    dell'applicazione. L'IP e la porta del server log sono contenuti dentro
    l'oggetto di tipo ParametriConfigurazioneXML.

11) Viene creata l'interfaccia grafica con i parametri di configurazione
    appena prelevati dal relativo file XML e impostando il contenuto della
    cache locale degli input.

12) Imposta lo stile dell'interfaccia grafica.

13) Alla chiusura dell'applicazione.

14) Viene inviato un log relativo alla chiusura dell'applicazione.

15) Viene salvata la cache locale degli input nell'apposito file.
*/