import java.util.ArrayList;
import java.util.List;
import javafx.scene.layout.*;

public class InterfacciaGrafica {//00
    private final BorderPane contenitore;
    private final pannelloSelezioneSpettacoli pannelloSx;
    private final pannelloVisualeDiagramma pannelloDx;
    private final pannelloPostazioniPlatea pannelloSelezionePosti;
    private final pannelloSuperioreLogo pannelloTop;
    private final pannelloVisualeEmailCliente pannelloBottom;
    
    public InterfacciaGrafica(ParametriConfigurazioneXML config, String fileCache) {
        contenitore = new BorderPane();//01
        
        pannelloSx=new pannelloSelezioneSpettacoli(config);
        pannelloDx=new pannelloVisualeDiagramma(config);
        pannelloSelezionePosti=new pannelloPostazioniPlatea(config);
        pannelloBottom=new pannelloVisualeEmailCliente(config);
        pannelloTop=new pannelloSuperioreLogo();
        
        Cache cache = GestoreCache.carica(fileCache);//07
        if(cache != null) { //08
            ripristinaValoriCache(cache);//09
        }
        else
            pannelloPostazioniPlatea.getMatricePlatea().inizializzaMatrice();
        
        //02
        contenitore.setTop(pannelloTop.getContenitore());
        contenitore.setLeft(pannelloSx.getContenitore());
        contenitore.setRight(pannelloDx.getContenitore());
        contenitore.setCenter(pannelloSelezionePosti.getContenitore());
        contenitore.setBottom(pannelloBottom.getContenitore());
    }
    
    public void ripristinaValoriCache(Cache cache) {//09
            //10
            pannelloSelezioneSpettacoli.getCitta().setValue(cache.getCittaSelezionata());
            pannelloSelezioneSpettacoli.getData().setValue(cache.getDataSelezionata());
            pannelloSelezioneSpettacoli.getOrario().setValue(cache.getOrarioSelezionato());
            pannelloVisualeEmailCliente.setCampoEmail(cache.getEmailCliente());
            
            //11
            gestoreRicercaEPrenotazioneSpettacoli.cercaSpettacoli(
                        pannelloSelezioneSpettacoli.getTabella(), pannelloSelezioneSpettacoli.getCitta(),
                    pannelloSelezioneSpettacoli.getData(), pannelloSelezioneSpettacoli.getOrario());
            
            //12
            pannelloSelezioneSpettacoli.getTabellaVisuale().getSelectionModel().clearSelection();
            pannelloSelezioneSpettacoli.getTabellaVisuale().getSelectionModel().select(
                cache.getIndiceRigaSpettacoloSelezionata()
            );
            
            //13
            int idSpettacoloSelezionato=cache.getIdSpettacoloSelezionato();
            List<postazionePlatea> listaDisponibilitaPostazioni=
                        GestoreDatabase.caricaDisponibilitaPostiSpettacoloSelezionato(idSpettacoloSelezionato);
            //14
            pannelloPostazioniPlatea.getMatricePlatea().caricaDisponibilitaPosti(listaDisponibilitaPostazioni);
            
            //15
            ArrayList<postazionePlatea> listaPostiSelezionati=cache.getListaSpettacoliSelezionati();
            for(postazionePlatea x:listaPostiSelezionati)
                pannelloPostazioniPlatea.getMatricePlatea().clickSelezioneIconaPostazioneVerde(
                        x.getIndiceRiga(),x.getIndiceColonna());
    }
    
    public static void resetInterfacciaGrafica(){//03
        pannelloSelezioneSpettacoli.getTabellaVisuale().getItems().clear();//04
        
        pannelloPostazioniPlatea.getMatricePlatea().inizializzaMatrice();//05
        
        pannelloPostazioniPlatea.getAreaCosti().resetPrezzi();//06
    }
        
    public BorderPane getContenitore(){ return contenitore; }
    public pannelloSelezioneSpettacoli getPannelloSx(){    return pannelloSx;    }
    
}


/***********************************COMMENTI***********************************/
/*
00) Classe responsabile della costruzione dell'interfaccia grafica dell'applicativo

01) Contenitore generico che divide l'applicativo in 5 sezioni.

02) Mano a mano aggiungo tutti i pannelli (sx,dx,cen,inf,sup) a quello generale.

03) Metodo chiamato su click bottone Annulla e Procedi, resetta l'interfaccia;
    in particolare svuota la tabella, resetta i prezzi (subtotale e totale)
    nell'areaCosti e rende non selezionabili le postazioni della platea.

04) Svuoto tabella spettacoli.

05) Rendo postazioni platea non selezionabili (grigie).

06) Resetto prezzi subtotale e totale nell'AreaCosti.

07) Utilizzo la classe GestoreCache per caricare dal file binario i valori salvati

08) Se il file cache.bin esiste

09) Allora ripristino da esso i valori contenuti relativi all'ultima esecuzione

10) Recupero dal file cache.bin i campi input inseriti e l'email

11) Rieseguo la ricerca con gli stessi parametri recuperati

12) Riseleziono la riga della tabella che era stata selezionata
  
13) Ripristino da cache anche l'id dello spettacolo selezionato dalla tabella
    perchè è necessario per il metodo di caricamento disponibilità postazioni

14) Innesco il caricamento della disponibilità dello spettacolo ad essa associato

15) Ripristino anche le postazioni selezionate (gialle)
*/