import javafx.scene.control.Label;
import javafx.scene.image.*;
import javafx.scene.layout.GridPane;
import javafx.scene.text.*;

public class areaCosti {
    private GridPane contenitoreAreaCosti;
    private Label etichettaSubtotale;
    private Label etichettaIVA;
    private Label etichettaTotale;
    private Label prezzoSubtotale;
    private Label prezzoIVA;
    private Label prezzoTotale;
    private ImageView legendaPosti;
    
    areaCosti(){
        contenitoreAreaCosti = new GridPane();//01
        
        inizializzaLabeleImmagineLegenda();
                      
        contenitoreAreaCosti.addRow(0, etichettaSubtotale);
        contenitoreAreaCosti.addRow(1, etichettaIVA);
        contenitoreAreaCosti.addRow(2, etichettaTotale);
        
        contenitoreAreaCosti.add(prezzoSubtotale,1,0);
        contenitoreAreaCosti.add(prezzoIVA,1,1);
        contenitoreAreaCosti.add(prezzoTotale,1,2);
        
        contenitoreAreaCosti.add(legendaPosti, 2, 1);
        contenitoreAreaCosti.setHgap(40);
    }
    
    public final void inizializzaLabeleImmagineLegenda(){
        //Label Prezzi
        prezzoSubtotale=new Label("0");
        prezzoSubtotale.setFont(Font.font("Arial", FontWeight.BOLD, 11));
        prezzoIVA=new Label("22");
        prezzoIVA.setFont(Font.font("Arial", FontWeight.BOLD, 11));
        prezzoTotale=new Label("0");
        prezzoTotale.setFont(Font.font("Arial", FontWeight.BOLD, 11));
        
        //Label Subtotale, IVA, Totale
        etichettaSubtotale = new Label("Subtotale");
        etichettaSubtotale.setFont(Font.font("Arial", FontWeight.BOLD, 11));
        etichettaIVA = new Label("IVA");
        etichettaIVA.setFont(Font.font("Arial", FontWeight.BOLD, 11));
        etichettaTotale = new Label("Totale");
        etichettaTotale.setFont(Font.font("Arial", FontWeight.BOLD, 11));
        
        //Immagine legenda posti
        legendaPosti = new ImageView(
          new Image("/immagini/legenda_posti.png"));
        legendaPosti.setFitHeight(50);
        legendaPosti.setFitWidth(160);
    }
    
    
     public void aggiornaPrezziSubtotaleETotale(){//02
       String old_value_SUBtotale_stringa=prezzoSubtotale.getText();
       double old_value_SUBtotale_intero=Double.parseDouble(old_value_SUBtotale_stringa);
       old_value_SUBtotale_intero+=10;
       prezzoSubtotale.setText(Double.toString(old_value_SUBtotale_intero));
       
       //03
       String iva_stringa=prezzoIVA.getText();
       int iva_intero=Integer.parseInt(iva_stringa);
       
       //04
       double incremento=(old_value_SUBtotale_intero*iva_intero)/100;
       double old_value_totale_intero=old_value_SUBtotale_intero+incremento;
       prezzoTotale.setText(Double.toString(old_value_totale_intero));
     }
     
     
     public void resetPrezzi(){
         prezzoTotale.setText("0");
         prezzoSubtotale.setText("0");
     }
    
    public GridPane getContenitore(){ return contenitoreAreaCosti; }
    public Label getPrezzoSubtotale(){  return prezzoSubtotale; }
    public Label getPrezzoTotale(){  return prezzoTotale; }
    public Label getIVA(){  return prezzoIVA; }
}



/***********************************COMMENTI***********************************/
/*
01) GridPane che conterrà i label, i label-prezzi e la legenda posti.

02) Funzione che aggiorna i campi label Subtotale e PrezzoTotale, richiamata a 
    seguito di ogni click su una postazione della platea libera (verde); Viene
    aggiunto +10 al Subtotale e viene aggiornato conseguentemente anche il campo
    Totale aggiungendo l'IVA.

03) Prelevo IVA per calcolare il PrezzoTotale a partire dal subtotale.

04) Aggiorno infine il PrezzoTotale.
*/