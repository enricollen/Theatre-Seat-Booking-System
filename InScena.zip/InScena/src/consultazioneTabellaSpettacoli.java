import java.util.List;
import javafx.scene.layout.*;


public class consultazioneTabellaSpettacoli {//00
    private final static int SPAZIATURA_CONTENITORE = 3;
    private final VBox contenitoreTabella;
    private final tabellaVisualeSpettacoli tabellaSpettacoli; 
    private int idSpettacoloSelezionato;
    private String titoloOperaSelezionata;
    
    public consultazioneTabellaSpettacoli(){
        
        contenitoreTabella=new VBox(SPAZIATURA_CONTENITORE);
        tabellaSpettacoli=new tabellaVisualeSpettacoli();
        
        
        tabellaSpettacoli.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {//01
        
            if (newSelection != null) {//02
                int index = tabellaSpettacoli.getSelectionModel().getSelectedIndex();
                spettacoloTeatrale rowSpettacoloSelezionato = tabellaSpettacoli.getItems().get(index);
                idSpettacoloSelezionato=rowSpettacoloSelezionato.getIdSpettacolo();
                
                //03
                List<postazionePlatea> listaDisponibilitaPostazioni=
                        GestoreDatabase.caricaDisponibilitaPostiSpettacoloSelezionato(idSpettacoloSelezionato);
                titoloOperaSelezionata=rowSpettacoloSelezionato.getTitoloOpera();
                
                //04
                pannelloPostazioniPlatea.getMatricePlatea().caricaDisponibilitaPosti(listaDisponibilitaPostazioni);
                
                //05
                pannelloPostazioniPlatea.getAreaCosti().resetPrezzi();
                                
                //07
                pannelloPostazioniPlatea.getMatricePlatea().svuotaListaPostiSelezionati();
                
                GestoreLogAttivitaXML.creaLog("Selezione spettacolo da tabella", InScena.config);
    }
    
    });
    }
    
    public VBox getContenitore() { return contenitoreTabella; }
    public tabellaVisualeSpettacoli getTabellaSpettacoli() { return tabellaSpettacoli; }
    public int getIdSpettacoloSelezionato(){   return idSpettacoloSelezionato;   }
    public String getTitoloOperaSelezionata(){   return titoloOperaSelezionata;   }
}

/***********************************COMMENTI***********************************/
/*
00) Classe FE avente come attributo la classe che ridefinisce tableview; gestisce
    la selezione di uno spettacolo da tabella e invoca il metodo della classe DB
    che carica la disponibilità di un dato spettacolo

01) Listener su selezione di una riga table view, corrispondente a uno spettacolo
    in programmazione e compatibile ai parametri di ricerca settati.

02) Ricavo la riga selezionata sfruttando le proprietà dei Bean e risalgo all'id
    dello spettacolo selezionato e al titolo dell'opera.

03) Ottengo la List delle postazioni singole relative ad uno spettacolo
    selezionato interrogando il db.

04) Chiamo il metodo della classe matriceSelezionePostiPlatea e carico disponibilità
    di ogni singolo posto in base a ogni elemento della List ottenuta dal db.

05) Richiamo il metodo della classe AreaCosti per azzerare i valori dei prezzi
    subtotale e totale ogni volta che selezioni un nuovo spettacolo.

06) Richiamo il metodo della classe MatriceSelezionePostiPlatea 
    per azzerare il numero della variabile postiSelezionati.

07) svuoto la lista dei posti selezionati se seleziono un altro spettacolo
    dalla tableview.
*/