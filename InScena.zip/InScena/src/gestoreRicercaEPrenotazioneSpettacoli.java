import java.util.ArrayList;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;

//classe MW
public class gestoreRicercaEPrenotazioneSpettacoli {//00
    
    public static void cercaSpettacoli(consultazioneTabellaSpettacoli contenitoreTabella,
            ComboBox sceltaCitta, DatePicker sceltaData, ComboBox sceltaOrario) {//01
        
            String citta=(String) sceltaCitta.getValue();
            java.sql.Date data = java.sql.Date.valueOf(sceltaData.getValue());//02
            String orario=(String) sceltaOrario.getValue();
        
            contenitoreTabella.getTabellaSpettacoli().aggiorna(
                GestoreDatabase.cercaSpettacoli(citta, data, orario));//03
    }
    
    public void prenotazioneOdisdetta(consultazioneTabellaSpettacoli tabella){
        
        if(pannelloPostazioniPlatea.getMatricePlatea().getListaPostiSelezionati().isEmpty())
                cancellaPrenotazione(tabella);
        else
                prenotazioneSpettacolo(tabella);
    }
    
    
    public void prenotazioneSpettacolo(consultazioneTabellaSpettacoli tabella){//04
        
        String email=(String) pannelloVisualeEmailCliente.getCampoEmail().getText();
        
        //salvo l'id univoco X della prenotazione restituito dalla insert nel DB
        //per poterlo poi usare nell'insert dei posti nella prenotazione con id X
        int id_prenotazione=GestoreDatabase.nuovaPrenotazioneSpettacolo(email,
                tabella.getIdSpettacoloSelezionato());
        
        ArrayList<postazionePlatea> listaPostiSelezionati=
                pannelloPostazioniPlatea.getMatricePlatea().getListaPostiSelezionati();//05
        
        for(postazionePlatea x:listaPostiSelezionati){
            
            GestoreDatabase.impostaStatoPostazioniPrenotate(
            tabella.getIdSpettacoloSelezionato(), x.getIndiceRiga(), x.getIndiceColonna());
            
            GestoreDatabase.inserisciPostiPrenotazione(//06
                id_prenotazione, x.getIndiceRiga(), x.getIndiceColonna() );
        }
        
        pannelloVisualeDiagramma.getGraficoTorta().aggiornaSliceSpettacoli();
        
        pannelloPostazioniPlatea.getMatricePlatea().caricaDisponibilitaPosti(//09
                GestoreDatabase.caricaDisponibilitaPostiSpettacoloSelezionato(
                        tabella.getIdSpettacoloSelezionato()
                )
        );
                        
        pannelloPostazioniPlatea.getMatricePlatea().svuotaListaPostiSelezionati();//11
        
        pannelloPostazioniPlatea.getAreaCosti().resetPrezzi();//12
    }
    
    public void cancellaPrenotazione(consultazioneTabellaSpettacoli tabella){//13
        String email=(String) pannelloVisualeEmailCliente.getCampoEmail().getText();
        
        int id_prenotazione_da_disdire=GestoreDatabase.ricavaIdPrenotazioneDaDisdire(email,
                tabella.getIdSpettacoloSelezionato());//14
        
        if(id_prenotazione_da_disdire!=-1){//14
        ArrayList<postazionePlatea> listaPostiDaLiberare=
                pannelloPostazioniPlatea.getMatricePlatea().getListaPostiDaLiberare();
        
        for(postazionePlatea x:listaPostiDaLiberare)//15
            GestoreDatabase.liberaPostazioniSelezionate(
            tabella.getIdSpettacoloSelezionato(), x.getIndiceRiga(), x.getIndiceColonna());
            
        GestoreDatabase.disdiciPrenotazione(email, tabella.getIdSpettacoloSelezionato());//16
        
        pannelloPostazioniPlatea.getMatricePlatea().svuotaListaPostiDaLiberare();//17
        }
        else
            System.out.println("Errore: email inserita e email proprietaria prenotazione non corrispondono!");
        
        pannelloVisualeDiagramma.getGraficoTorta().aggiornaSliceSpettacoli();//18
        
        pannelloPostazioniPlatea.getMatricePlatea().caricaDisponibilitaPosti(//09
                GestoreDatabase.caricaDisponibilitaPostiSpettacoloSelezionato(
                        tabella.getIdSpettacoloSelezionato()
                )
        );
    }
}


/***********************************COMMENTI***********************************/
/*
00) Classe MW che viene richiamata a seguito della pressione del pulsante PROCEDI,
    per effettuare prenotazioni o disdirle.

01) Funzione richiamata dopo la pressione del bottone Cerca; responsabile di
    collezionare tutti i valori dei campi input e invocare il metodo aggiorna
    della tabellaVisualeSpettacoli.

02) Converto da DatePicker a Oggetto Date, necessario per settare il parametro
    del PreparedStatement tramite setDate.

03) Il metodo aggiorna della classe tabellaVisualeSpettacoli ha come parametro
    la List restituita dal metodo della classe GestoreDatabase che ottiene
    gli spettacoli compatibili interrogando il DB.

04) Funzione richiamata dopo la pressione del bottone Prosegui; responsabile di
    inserire nel DB una nuova prenotazione di un cliente e di aggiornare lo stato
    delle postazioni selezionate settandolo a 1 (prenotate) in modo che al
    successivo caricamento della platea posti risultino rosse e quindi
    non selezionabili.

05) Ottengo dalla matrice la lista dei posti selezionati, aventi ognuno un indice
    riga e un indice colonna: per ognuno di essi andrò a settare lo stato=1 nel DB
    in modo che al successivo caricamento della platea posti risultino rosse
    e quindi non selezionabili.

06) Metodo della classe DB che permette inserisce nella tabella
    postazioni_x_prenotazioni tutte le postazioni (con indice riga e colonna)
    selezionate per una data prenotazione

07) Devo aggiornare il numero di biglietti venduti nella prenotazione, che
    corrisponde ad un aumento della popolarità dell'opera prenotata.

08) Qui vado ad aggiornare la lista osservabile, modificando la popolarità
    in termini di biglietti venduti (che vengono aggiunti ai precedenti)
    dell opera coinvolta nella prenotazione. Il diagramma a torta
    si aggiorna essendo stata modificata la lista osservabile.

09) Aggiornamento disponibilità postazioni spettacolo dopo aver
    confermato/disdetto la prenotazione.

10) Richiamo il metodo della classe MatriceSelezionePostiPlatea 
    per azzerare il numero della variabile postiSelezionati.

11) svuoto la lista dei posti selezionati se seleziono un altro spettacolo
    dalla tableview.

12) Richiamo il metodo della classe AreaCosti per azzerare i valori dei prezzi
    subtotale e totale ogni volta che viene effettuata una nuova prenotazione.

13) Metodo per disdire una prenotazione

14) Serve per vedere se a disdire è effettivamente il possessore della prenotazione.
    Se ricevo -1 come ritorno, le email non corrispondono e stampo un semplice msg
    d'errore    

15) Per ogni postazione contenuta nella lista invoco il metodo della classe BD
    che va a settare lo stato di tale postazione = 0, liberandola.

16) Richiamo successivamente anche il metodo della classe DB per eliminare i record
    relativi alla prenotazione appena disdetta

17) Resetto la lista dei posti da liberare

18) Richiamo l'aggiornamento del grafico 
*/