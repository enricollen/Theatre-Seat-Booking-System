import java.util.List;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.chart.PieChart;

public class graficoSpettacoli extends PieChart{//00
    private ObservableList<PieChart.Data> listaSpettacoli; 
    
    public graficoSpettacoli(ObservableList<PieChart.Data> list){//01
        super(list);
        listaSpettacoli=list;
        setPrefWidth(400);
    }
    
    public void aggiornaListaSpettacoliPopolari(ObservableList<PieChart.Data> list){//02
        this.listaSpettacoli.clear();
        for(PieChart.Data x:list)
            listaSpettacoli.addAll(x);
    }
    
    public void aggiornaSliceSpettacoli(){//03
        List<popolaritaOperaTeatrale> listaSpettacoli=
                GestoreDatabase.getListaSpettacoliPiuPopolari(
                        InScena.config.getPeriodoInGiorniDaOggi(), 
                        InScena.config.getNumeroSpettacoliPopolariDaMostrare());
        
        ObservableList<PieChart.Data> listaOsservabileSpettacoli=
                FXCollections.observableArrayList();
        
        int bigliettiAltri=0;
        for(popolaritaOperaTeatrale x:listaSpettacoli){//04
            if(listaOsservabileSpettacoli.size()<InScena.config.getNumeroSpettacoliPopolariDaMostrare())
            listaOsservabileSpettacoli.add(new PieChart.Data(x.getTitoloOpera(), x.getNumeroBiglietti()));
            else bigliettiAltri+=x.getNumeroBiglietti();
        }
        listaOsservabileSpettacoli.add(new PieChart.Data("Altri", bigliettiAltri));
        
        aggiornaListaSpettacoliPopolari(//02
                listaOsservabileSpettacoli
        );
    }
    
    public  ObservableList<PieChart.Data> getListaOsservabileSpettacoli(){   return listaSpettacoli;    }
}

/***********************************COMMENTI***********************************/
/*
00) Classe che rappresenta il diagramma a torta posto sulla destra dell'applicativo

01) Al costruttore viene passata una List degli spettacoli che andranno a comporre
    la top-X

02) Metodo per aggiornare la Obs List e quindi aggiornare il grafico

03) Metodo per aggiornare gli 'Slice' del diagramma; ogni volta leggo dal file di
    configurazione locale il numero X di spettacoli da mostare e il numero di giorni
    G da tenere in considerazione a partire da oggi per costruire la classifica

04) Costruisco la fetta 'Altri' con tutte le opere che non rientrano nella top-X;
    in particolare la fetta è grande tanto quanto la sommatoria dei biglietti venduti
    per gli spettacoli che non rientrano nella top-X
*/