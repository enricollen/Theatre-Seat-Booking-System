import java.util.ArrayList;
import java.util.List;
import javafx.geometry.HPos;
import javafx.scene.control.Label;
import javafx.scene.image.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;


public class matriceSelezionePostiPlatea {//00
    private GridPane contenitorePlatea;
    private ImageView[][] matriceImmaginiPosto;
    private ArrayList<postazionePlatea> listaPostiSelezionati;
    private ArrayList<postazionePlatea> listaPostiDaLiberare;
    
    matriceSelezionePostiPlatea(){
    listaPostiSelezionati=new ArrayList<>();//01
    listaPostiDaLiberare=new ArrayList<>();//01
    contenitorePlatea = new GridPane();
    inizializzaMatrice();
    
    contenitorePlatea.setVgap(7);
    contenitorePlatea.setHgap(7);
    }
    
    public final void inizializzaMatrice(){//02
        
        this.matriceImmaginiPosto = new ImageView[5][8];
        for(int i=0; i<5; i++){
            for(int j=0; j<8; j++){
                if(i==0 && j==0) continue; //03
                if(i==0 && j!=0){ //04
                    int k=(i==0)?j:i;//05
                    Label x=new Label(Integer.toString(k)); //06
                    contenitorePlatea.add(x,j,i); //07
                    GridPane.setHalignment(x, HPos.CENTER); //08
                }
                else if(i!=0 && j==0){//09
                    Label x=new Label(String.valueOf(Character.toChars(65+i-1)));//10
                    contenitorePlatea.add(x,j,i); //11
                    GridPane.setHalignment(x, HPos.CENTER);//08
                }
                else{//12
                  matriceImmaginiPosto[i][j]=new ImageView(new Image("/immagini/posto_non_selezionabile.png"));
                  //sintassi per il gridpane che vuole prima colonna j e riga i
                  //gli ultimi due indici sono la spaziatura
                  contenitorePlatea.add(matriceImmaginiPosto[i][j], j, i, 1, 1);
                }
            }
        }
        
    }
    
    
    public void caricaDisponibilitaPosti(List<postazionePlatea> listaDisponibilitaPostazioni){//28
        
        contenitorePlatea.getChildren().clear();//29
        
        for(int i=0; i<5; i++){
            for(int j=0; j<8; j++){
                if(i==0 && j==0) continue; //03
                if(i==0 && j!=0){ //04
                    int k=(i==0)?j:i;//05
                    Label x=new Label(Integer.toString(k));//06
                    contenitorePlatea.add(x,j,i); //07
                    GridPane.setHalignment(x, HPos.CENTER); //08
                }
                else if(i!=0 && j==0){//09
                    Label x=new Label(String.valueOf(Character.toChars(65+i-1)));//10
                    contenitorePlatea.add(x,j,i); //11
                    GridPane.setHalignment(x, HPos.CENTER);//08
                }
                else{//12
                     
                    for(postazionePlatea x : listaDisponibilitaPostazioni)
                        if(x.getIndiceRiga()==i && x.getIndiceColonna()==j)//13
                            
                        if(x.getStatoPostazione()==0){//14
                            matriceImmaginiPosto[i][j]=new ImageView(new Image("/immagini/posto_libero.png"));
                                                        
                            //15
                            final int riga=i; 
                            final int colonna=j;
                            
                            matriceImmaginiPosto[i][j].setOnMouseClicked((MouseEvent e) -> {
                                clickSelezioneIconaPostazioneVerde(riga, colonna);//17
                            } //16
                            );
                            break;
                        }
                        else{//18
                            matriceImmaginiPosto[i][j]=new ImageView(new Image("/immagini/posto_occupato.png")); 
                            //15
                            final int riga=i; 
                            final int colonna=j;
                            
                            matriceImmaginiPosto[i][j].setOnMouseClicked((MouseEvent e) -> {
                                clickSelezioneIconaPostazioneRossa(riga, colonna);
                            }
                            );
                            break;
                        }
                        
                        //27
                        contenitorePlatea.add(matriceImmaginiPosto[i][j], j, i, 1, 1);
                }
            }
        }
    }
    
     public void clickSelezioneIconaPostazioneVerde(int i, int j) {//17
//       GestoreLogAttivitaXML.creaLog("Click selezione posto "+i+"-"+j, InScena.config);
       contenitorePlatea.getChildren().remove(matriceImmaginiPosto[i][j]);//19
       matriceImmaginiPosto[i][j]=null;//20
       matriceImmaginiPosto[i][j]=new ImageView(new Image("/immagini/posto_selezionato.png"));//21
       contenitorePlatea.add(matriceImmaginiPosto[i][j], j, i, 1, 1);//22
       
       pannelloPostazioniPlatea.getAreaCosti().aggiornaPrezziSubtotaleETotale();//23
       listaPostiSelezionati.add(new postazionePlatea(i,j,1));//25
     }
     
     public void clickSelezioneIconaPostazioneRossa(int i, int j) {//17
       contenitorePlatea.getChildren().remove(matriceImmaginiPosto[i][j]);//19
       matriceImmaginiPosto[i][j]=null;//20
       matriceImmaginiPosto[i][j]=new ImageView(new Image("/immagini/posto_selezionato.png"));//21
       contenitorePlatea.add(matriceImmaginiPosto[i][j], j, i, 1, 1);
       
       String email=pannelloVisualeEmailCliente.getCampoEmail().getText();
       listaPostiDaLiberare.add(new postazionePlatea(i,j,1));
     }
     
    
    public ImageView[][] getMatricePosti(){ return matriceImmaginiPosto; }
    public GridPane getContenitore(){ return contenitorePlatea; }
    public ArrayList<postazionePlatea> getListaPostiSelezionati(){  return listaPostiSelezionati; }
    public ArrayList<postazionePlatea> getListaPostiDaLiberare(){  return listaPostiDaLiberare; }
    public void svuotaListaPostiSelezionati(){  listaPostiSelezionati.clear();  }
    public void svuotaListaPostiDaLiberare(){  listaPostiDaLiberare.clear();  }
}

/***********************************COMMENTI***********************************/
/*
00) Classe FE che rappresenta la matrice della platea di selezione posti; inizializza
    e gestisce i click su ogni postazione.

01) Serve per salvare i posti selezionati; Viene passata al pannello sx quando 
    si preme il bottone PROCEDI.Sarà cosi possibile settare il loro stato
    a 1 nel db, seguendo le coordinate riga/colonna dei posti selezionati.

02) Funzione di utilità che inizializza la matrice come "non selezionabile",
    così come tutti i posti che presenteranno un icona grigia.

03) Il campo 0,0 non viene stampato.

04) Condizione della riga n.0, devo stampare indici numerici relativi alle colonne.

05) Salvo in k l'indice non nullo tra i due.

06) Ricavo il numero k non nullo, e lo converto in stringa.

07) Aggiungo alla cella l'intero corrispondente all'indice della colonna.

08) Centro i numeri nelle celle orizzontalmente.

09) Condizione della colonna n.0, devo stampare le lettere relativi alle righe.

10) Ricavo la lettera convertendo l'intero i in ASCII, sapendo che 'A' parte da 65

11) Aggiungo alla cella con lettera corrispondente appena ricavata.

12) Se sono in mezzo alla tabella, stampo immagini postazioni.

13) Cerco nella List di postazionePlatea, il posto corrispondente a i j,
    sfruttando i metodi get che restituiscono i campi interi riga/colonna.

14) Se la postazione risulta libera

15) Variabili ausiliare final perchè per passare variabili locali alla 
    ridefinizione di "handle()", queste devono essere final.

16) Evento su click icona postazione (ridefinizione della fx handle per le ImageView).
    Aggiungo l'event handler solo per le postazioni libere verdi, e quindi
    selezionabili (per quelle rosse non succede niente).

17) Funzione che si attiva al click su un icona verde, e colora icona di giallo.

18) Se la postazione risulta occupata

19) Rimuovo il nodo figlio dal GridPane (ImageView posto libero verde)

20) Resetto l'icona riga i colonna j

21) E la rendo selezionata gialla

22) aggiungo infine l'icona aggiornata

23) ad ogni selezione devo aggiornare i campi label Subtotale e PrezzoTotale;
    Per farlo utilizzo il metodo della classe areaCosti.

24) Aumento ad ogni click il numero delle postazioni selezionate.

25) Aggiungo il posto alla lista delle postazioni selezionate, che poi
    verrà restituita per prenotarle.

26) Funzione d'utilità che viene chiamata per azzerare il numero dei posti 
    selezionati quando viene selezionato un altro spettacolo dalla tableview.
    Necessario per far ripartire il conto.

27) Aggiungo infine la image view verde o rossa.

28) Funzione per caricare posti verdi o rossi in base alla selezione di uno
    spettacolo da tabella.

29) svuota il gridpane dalle postazioni grigie e rimpiazza con icone
    in base alla disponibilità data dalla lista passata come argomento.
*/

