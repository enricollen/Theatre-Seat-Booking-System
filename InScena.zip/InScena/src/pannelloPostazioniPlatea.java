import javafx.geometry.*;
import javafx.scene.control.*;
import javafx.scene.image.*;
import javafx.scene.layout.*;
import javafx.scene.text.*;

public class pannelloPostazioniPlatea {//00

    private final GridPane contenitorePannelloCentrale;
    private static matriceSelezionePostiPlatea matricePlatea;
    private static areaCosti pannelloAreaCosti;
    private Label titoloPannelloCentrale;
    ImageView immagineStage;
    
    public pannelloPostazioniPlatea(ParametriConfigurazioneXML config){
        contenitorePannelloCentrale = new GridPane();
        matricePlatea=new matriceSelezionePostiPlatea();
        pannelloAreaCosti=new areaCosti();

        inizializzaComponenti();
        impostaStileComponenti(config);
        
        //Aggiungo il contenitore della classe matrice platea
        contenitorePannelloCentrale.addRow(2,matricePlatea.getContenitore());
        
        //Aggiungo l'area costi sottostante la platea
        contenitorePannelloCentrale.addRow(3,pannelloAreaCosti.getContenitore());
    }
    
    public final void inizializzaComponenti(){
        // Immagine Palco
        immagineStage = new ImageView(
        new Image("/immagini/stage.jpg"));
        titoloPannelloCentrale = new Label("Selezione Posti");
        contenitorePannelloCentrale.addColumn(0, titoloPannelloCentrale);
        contenitorePannelloCentrale.add(immagineStage, 0, 1); 
    }
    
    public final void impostaStileComponenti(ParametriConfigurazioneXML config){
        titoloPannelloCentrale.setFont(Font.font("Arial", FontWeight.BOLD, 14));
        immagineStage.setFitHeight(120);
        immagineStage.setFitWidth(270);
        GridPane.setHalignment(titoloPannelloCentrale, HPos.CENTER);
        GridPane.setHalignment(immagineStage, HPos.CENTER);
        contenitorePannelloCentrale.setAlignment(Pos.CENTER);
        contenitorePannelloCentrale.setStyle("-fx-background-color: "+config.getColoreSfondo()+";");
        contenitorePannelloCentrale.setPrefWidth(400); 
        //questi 2 parametri servono a distanziare gli elementi delle celle in altezza e larghezza
        contenitorePannelloCentrale.setHgap(10);
        contenitorePannelloCentrale.setVgap(10);
    }
    
    public GridPane getContenitore(){ return contenitorePannelloCentrale; }
    public static matriceSelezionePostiPlatea getMatricePlatea(){  return matricePlatea;   }
    public static areaCosti getAreaCosti(){    return pannelloAreaCosti;   }
}

/***********************************COMMENTI***********************************/
/*
00) Classe FE inclusa da InterfacciaGrafica che corrisponde al pannello Centrale
    dell'applicativo; contiene la classe relativa alla matrice di selezione posti,
    l'area dei costi e detta lo stile del pannello.
*/