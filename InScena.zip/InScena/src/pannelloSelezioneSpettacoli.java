import java.time.LocalDate;
import javafx.collections.*;
import javafx.event.ActionEvent;
import javafx.geometry.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.*;

public class pannelloSelezioneSpettacoli {//00
    private VBox contenitorePannelloSinistro;
    private HBox contenitoreBottoni;
    Label titoloPannelloSinistro, etichettaCitta, etichettaData,
            etichettaOrario, titoloTabella;
    Button bottoneCerca, bottoneProcedi, bottoneAnnulla;
    private static ComboBox selezioneCitta;
    private static ComboBox selezioneOrario;
    private static DatePicker selezioneData;
    private static consultazioneTabellaSpettacoli ts;
    private gestoreRicercaEPrenotazioneSpettacoli gestoreEventiRicercaPrenotazione;
    
    public pannelloSelezioneSpettacoli(ParametriConfigurazioneXML config){
            inizializzaComponenti();
            impostaStileComponenti(config);
            
            bottoneCerca.setOnAction((ActionEvent ev)->{//01
                gestoreRicercaEPrenotazioneSpettacoli.cercaSpettacoli(
                        ts, selezioneCitta, selezioneData, selezioneOrario);
                GestoreLogAttivitaXML.creaLog("Pressione bottone CERCA", InScena.config);
            });
            
            bottoneAnnulla.setOnAction((ActionEvent ae)->{//02
                InterfacciaGrafica.resetInterfacciaGrafica();
                pannelloPostazioniPlatea.getMatricePlatea().svuotaListaPostiSelezionati();
                GestoreLogAttivitaXML.creaLog("Pressione bottone ANNULLA", InScena.config);
            });
            
            bottoneProcedi.setOnAction((ActionEvent ae)->{//03
                gestoreEventiRicercaPrenotazione.prenotazioneOdisdetta(ts);
                GestoreLogAttivitaXML.creaLog("Pressione bottone PROCEDI", InScena.config);
            });
            
            //04
            contenitorePannelloSinistro.getChildren().add(titoloPannelloSinistro);      
            contenitoreBottoni.getChildren().addAll(bottoneAnnulla,bottoneProcedi);
            contenitorePannelloSinistro.getChildren().addAll(etichettaCitta, selezioneCitta, 
                    etichettaData, selezioneData, etichettaOrario, selezioneOrario, bottoneCerca,
                    titoloTabella, ts.getTabellaSpettacoli(), contenitoreBottoni);
    }
    
    public final void inizializzaComponenti(){
            gestoreEventiRicercaPrenotazione= new gestoreRicercaEPrenotazioneSpettacoli();
            contenitorePannelloSinistro = new VBox();
            contenitoreBottoni = new HBox();
            bottoneCerca = new Button("CERCA");
            bottoneProcedi = new Button("PROCEDI");
            bottoneAnnulla = new Button("ANNULLA");
            titoloPannelloSinistro = new Label("Prenotazione");
            etichettaCitta = new Label("Città");
            etichettaData = new Label("Data");
            etichettaOrario = new Label("Orario");
            titoloTabella=new Label("Spettacoli");
            selezioneData = new DatePicker();
            selezioneData.setValue(LocalDate.of(2020, 4, 04)); //LocalDate.now()
            ts=new consultazioneTabellaSpettacoli();
            
            ObservableList<String> elencoCitta = 
            FXCollections.observableArrayList(
                "Livorno",
                "Lucca",
                "Pisa"
            );
            
            ObservableList<String> elencoOrari = 
            FXCollections.observableArrayList(
                "20:00",
                "21:00"
            );
            
            selezioneCitta = new ComboBox(elencoCitta);
            selezioneCitta.setValue("Livorno");
            selezioneOrario = new ComboBox(elencoOrari);
            selezioneOrario.setValue("20:00");
    }
    
    public final void impostaStileComponenti(ParametriConfigurazioneXML config){
        contenitorePannelloSinistro.setPadding(new Insets(15));
        contenitorePannelloSinistro.setSpacing(10);
        titoloPannelloSinistro.setFont(Font.font("Arial", FontWeight.BOLD, 14));
        contenitoreBottoni.setAlignment(Pos.CENTER);
        contenitoreBottoni.setSpacing(10);
        bottoneCerca.setPrefSize(100, 20);
        bottoneProcedi.setPrefSize(100, 20);
        bottoneAnnulla.setPrefSize(100, 20);
        contenitorePannelloSinistro.setAlignment(Pos.CENTER);
        contenitorePannelloSinistro.setPrefWidth(400);
        contenitorePannelloSinistro.setStyle("-fx-background-color: "+config.getColoreSfondo()+";");
        etichettaData.setFont(Font.font(config.getFont(), config.getDimensioneFont()));
        etichettaOrario.setFont(Font.font(config.getFont(), config.getDimensioneFont()));
        titoloTabella.setFont(Font.font(config.getFont(), config.getDimensioneFont()));
        etichettaCitta.setFont(Font.font(config.getFont(), config.getDimensioneFont()));
    }
    
    public VBox getContenitore(){ return contenitorePannelloSinistro; }
    
    public static tabellaVisualeSpettacoli getTabellaVisuale(){   return ts.getTabellaSpettacoli();   }
    public static consultazioneTabellaSpettacoli getTabella(){   return ts;   }
    public static ComboBox getCitta(){ return selezioneCitta;  }
    public static ComboBox getOrario(){ return selezioneOrario;  }
    public static DatePicker getData(){ return selezioneData;  }
}


/***********************************COMMENTI***********************************/
/*
00) Classe FE inclusa da InterfacciaGrafica che rappresenta il pannello sinistro
    dell'applicativo. Regola lo stile delle componenti e gestisce eventi sui
    bottoni Cerca/Annulla/Procedi.

01) Event Handler su click pulsante CERCA; viene richiamato il metodo cercaSpettacoli
    della classe gestoreRicercaEPrenotazioneSpettacoli, che a sua volta tramite
    un metodo della classe GestoreDatabase interrogherà il DB, e legherà la lista
    degli spettacoli restituita alla table view.

02) Event Handler su click pulsante ANNULLA; viene resettata l'interfaccia grafica

03) Event Handler su click pulsante PROCEDI; viene richiamato il metodo
    prenotazioneSpettacolo della classe gestoreRicercaEPrenotazioneSpettacoli,
    che a sua volta tramite un metodo della classe GestoreDatabase inserirà
    nel DB tutti i valori selezionati, compreso il campo email cliente.

04) Vengono inserite tutte le componenti nei rispettivi contenitori
*/