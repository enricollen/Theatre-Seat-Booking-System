import javafx.geometry.*;
import javafx.scene.image.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;

public class pannelloSuperioreLogo {//00
    private final HBox contenitorePannelloSuperiore;
    
    public pannelloSuperioreLogo(){
        contenitorePannelloSuperiore = new HBox();
        contenitorePannelloSuperiore.setSpacing(10);
        contenitorePannelloSuperiore.setStyle("-fx-background-color: #46679c;");

        ImageView logo = new ImageView(new Image("/immagini/InScenaLogo.png"));
        logo.setOnMouseClicked((MouseEvent e) -> {
            InterfacciaGrafica.resetInterfacciaGrafica();
            GestoreLogAttivitaXML.creaLog("Pressione su Logo InScena", InScena.config);
        });
        
        logo.setFitHeight(120);
        logo.setFitWidth(250);
        contenitorePannelloSuperiore.getChildren().addAll(logo);
        contenitorePannelloSuperiore.setAlignment(Pos.CENTER);
    }
    
    public HBox getContenitore(){ return contenitorePannelloSuperiore; }
}

/***********************************COMMENTI***********************************/
/*
00) Classe FE inclusa da InterfacciaGrafica che rappresenta il pannello superiore
    dell'applicativo. Contiene l'immagine Logo InScena e gestisce il click su di essa
*/
