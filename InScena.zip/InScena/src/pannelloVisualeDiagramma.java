import java.util.List;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.*;
import javafx.scene.chart.PieChart;
import javafx.scene.layout.FlowPane;
import javafx.scene.text.*;

public class pannelloVisualeDiagramma {//00
    private FlowPane contenitorePannelloDestro;
    Text title;
    private static graficoSpettacoli graficoTorta;
    
    pannelloVisualeDiagramma(ParametriConfigurazioneXML config){
        inizializzaComponenti();
        impostaStileComponenti(config);
        contenitorePannelloDestro.getChildren().add(title);
        contenitorePannelloDestro.getChildren().addAll(graficoTorta);
    }
    
     public final void inizializzaComponenti(){
         contenitorePannelloDestro= new FlowPane();
         title = new Text("Più Popolari");
         
        List<popolaritaOperaTeatrale> listaSpettacoli=
                GestoreDatabase.getListaSpettacoliPiuPopolari(
                        InScena.config.getPeriodoInGiorniDaOggi(), 
                        InScena.config.getNumeroSpettacoliPopolariDaMostrare());//01
        
        ObservableList<PieChart.Data> listaOsservabileSpettacoli=
                FXCollections.observableArrayList();//02
        
        int bigliettiAltri=0;
        for(popolaritaOperaTeatrale x:listaSpettacoli){//03
            if(listaOsservabileSpettacoli.size()<InScena.config.getNumeroSpettacoliPopolariDaMostrare())
            listaOsservabileSpettacoli.add(new PieChart.Data(x.getTitoloOpera(), x.getNumeroBiglietti()));
            else bigliettiAltri+=x.getNumeroBiglietti();
        }
        listaOsservabileSpettacoli.add(new PieChart.Data("Altri", bigliettiAltri));
        
        graficoTorta=new graficoSpettacoli(listaOsservabileSpettacoli);
    }
    
    public final void impostaStileComponenti(ParametriConfigurazioneXML config){
        contenitorePannelloDestro.setVgap(4);
        contenitorePannelloDestro.setHgap(4);
        contenitorePannelloDestro.setMaxSize(400, 600);
        title.setFont(Font.font("Arial", FontWeight.BOLD, 14));
        contenitorePannelloDestro.setStyle("-fx-background-color: "+config.getColoreSfondo()+";");
        contenitorePannelloDestro.setAlignment(Pos.CENTER);
    }
    
    public FlowPane getContenitore(){ return contenitorePannelloDestro; }
    public static graficoSpettacoli getGraficoTorta(){ return graficoTorta;   }
}

/***********************************COMMENTI***********************************/
/*
00) Classe FE inclusa da InterfacciaGrafica che rappresenta il pannello destro
    dell'applicativo. Ha come attributo il diagramma relativo agli spettacoli
    piu popolari, e lo inizializza costruendo all'avvio la top-X, richiesta alla 
    classe DB tramite il metodo apposito. Regola lo stile delle componenti.

01) Il DB restituisce una List di oggetti popolaritaOperaTeatrale, ognuno con
    il titolo dell'opera e la relativa "popolarita", calcolata in termini di 
    biglietti venduti.

02) E' necessario però passare al grafico una Obs List per inizializzarlo,
    quindi ne creo una vuota.

03) Per ogni oggetto popolaritaOperaTeatrale appartenente alla List restituita 
    dal DB, se la popolarità non è 0, aggiungo alla lista osservabile un nuovo
    oggetto PieChart.Data con stesso nome opera e stessa popolarita dell'oggetto
    nella List.
*/