import javafx.geometry.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Font;

public class pannelloVisualeEmailCliente {//00
    private final HBox contenitorePannelloInferiore;
    final Label etichettaEmail;
    private static TextField campoInserimentoEmail;
    
    public pannelloVisualeEmailCliente(ParametriConfigurazioneXML config){
        etichettaEmail=new Label("Email");
        etichettaEmail.setFont(Font.font(config.getFont(), config.getDimensioneFont()));
        campoInserimentoEmail=new TextField();
        campoInserimentoEmail.setMaxWidth(200);
        contenitorePannelloInferiore = new HBox();
        contenitorePannelloInferiore.setSpacing(10);
        contenitorePannelloInferiore.setStyle("-fx-background-color: #46679c;");

        
        contenitorePannelloInferiore.getChildren().addAll(etichettaEmail,campoInserimentoEmail);
        contenitorePannelloInferiore.setAlignment(Pos.CENTER);
        contenitorePannelloInferiore.setPadding(new Insets(10));
    }
    
    public HBox getContenitore(){ return contenitorePannelloInferiore; }
    public static TextField getCampoEmail(){    return campoInserimentoEmail;  }
    public static void setCampoEmail(String e){    campoInserimentoEmail.setText(e);  }
}

/***********************************COMMENTI***********************************/
/*
00) Classe FE inclusa da InterfacciaGrafica che rappresenta il pannello inferiore
    dell'applicativo. Contiene il campo di inserimento email, per l'autenticazione
    dell'utente e regola lo stile delle proprie componenti.
*/