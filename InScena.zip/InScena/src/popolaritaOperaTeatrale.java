import javafx.beans.property.*;

public class popolaritaOperaTeatrale {//00
    private final SimpleStringProperty titoloOpera;
    private final SimpleIntegerProperty numeroBigliettiVenduti;
    
    public popolaritaOperaTeatrale(String opera, int bigliettiVenduti){
        this.titoloOpera=new SimpleStringProperty(opera);
        this.numeroBigliettiVenduti=new SimpleIntegerProperty(bigliettiVenduti);
    }
    
    public String getTitoloOpera() { return titoloOpera.get(); }
    public int getNumeroBiglietti() { return numeroBigliettiVenduti.get(); }
}

/***********************************COMMENTI***********************************/
/*
00) Classe Bean che rappresenta un opera teatrale interna al diagramma a torta,
    associata alla relativa popolarità (intesa come numero di biglietti venduti)
*/