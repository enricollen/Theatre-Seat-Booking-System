import java.io.Serializable;

public class postazionePlatea implements Serializable{//00
    private int indiceColonna;
    private int indiceRiga;
    private int statoPostazione;
    
    postazionePlatea(int indice_row, int indice_col, int stato){
        this.indiceRiga=indice_row;
        this.indiceColonna=indice_col;
        this.statoPostazione=stato;
    }
    
    public int getIndiceRiga(){  return this.indiceRiga;  }
    public int getIndiceColonna(){  return this.indiceColonna;  }
    public int getStatoPostazione(){  return this.statoPostazione;  }
    public void setStatoPostazione(){   this.statoPostazione=1; }
}

/***********************************COMMENTI***********************************/
/*
00) Classe di utilità che serve per rappresentare una postazione della platea.
    ha come attributi indice riga, colonna e stato ed è utlizzata come membro
    di List per mantenere informazioni relative alla selezione dei posti da 
    prenotare/disdire.
*/
