import javafx.beans.property.*;

public class spettacoloTeatrale {//00
    private final SimpleStringProperty nomeTeatro;
    private final SimpleStringProperty titoloOpera;
    private final SimpleStringProperty genereOpera;
    private final SimpleStringProperty linkOpera;
    private final SimpleIntegerProperty idSpettacolo;
    
    public spettacoloTeatrale(int id,String teatro, String titolo, String genere, String link){
        this.nomeTeatro=new SimpleStringProperty(teatro);
        this.titoloOpera=new SimpleStringProperty(titolo);
        this.genereOpera=new SimpleStringProperty(genere);
        this.linkOpera=new SimpleStringProperty(link);
        this.idSpettacolo=new SimpleIntegerProperty(id);
    }
    
    public String getNomeTeatro() { return nomeTeatro.get(); }
    public String getTitoloOpera() { return titoloOpera.get(); }
    public String getGenereOpera() { return genereOpera.get(); }
    public String getLinkOpera() { return linkOpera.get(); }
    public int getIdSpettacolo() { return idSpettacolo.get(); }
}

/***********************************COMMENTI***********************************/
/*
00) Classe Bean avente stessi campi di un record della tabella, e rappresentante
    di fatto uno spettacolo in programmazione
*/