import java.util.List;
import javafx.collections.*;
import javafx.scene.control.*;
import javafx.scene.control.cell.*;

//FE
public class tabellaVisualeSpettacoli extends TableView<spettacoloTeatrale>{//00
    private final ObservableList<spettacoloTeatrale> listaSpettacoli; 
    
    public tabellaVisualeSpettacoli(){
        listaSpettacoli=FXCollections.observableArrayList();
        
        TableColumn idCol = new TableColumn("Id");
        idCol.setCellValueFactory(new PropertyValueFactory<>("idSpettacolo"));
        TableColumn teatroCol = new TableColumn("Teatro");
        teatroCol.setCellValueFactory(new PropertyValueFactory<>("nomeTeatro"));
        TableColumn titoloCol = new TableColumn("Opera");
        titoloCol.setCellValueFactory(new PropertyValueFactory<>("titoloOpera"));
        TableColumn genereCol = new TableColumn("Genere");
        genereCol.setCellValueFactory(new PropertyValueFactory<>("genereOpera"));
        TableColumn linkCol = new TableColumn("Dettagli");
        linkCol.setCellValueFactory(new PropertyValueFactory<>("linkOpera"));
        
        //regolo larghezza colonne e larghezza tabella
        idCol.prefWidthProperty().bind(widthProperty().divide(10));
        genereCol.prefWidthProperty().bind(widthProperty().divide(4));
        linkCol.prefWidthProperty().bind(widthProperty().divide(2.3));
        setPrefWidth(300);
        
        //lego listaSpettacoli alla tabella
        setItems(listaSpettacoli);
        
        //aggiungo colonne
        getColumns().addAll(teatroCol, titoloCol, genereCol, linkCol);
    }
    
    public void aggiorna(List<spettacoloTeatrale> spettacoli) {
        listaSpettacoli.clear();
        listaSpettacoli.addAll(spettacoli);
    }
    
    public ObservableList<spettacoloTeatrale> getListaOpere() { return listaSpettacoli; }
}

/***********************************COMMENTI***********************************/
/*
00) Classe che estende TableView, è un attributo della classe
    ConsultazioneTabellaSpettacoli.
*/